# go-getter

Lite version with fewer dependency.

S3 and GCS is not supported.
