package validate

import (
	"testing"
)

// This test must be synchronized to avoid issues with -race
// TODO(TEST)
func TestOptions_SetContinueOnErrors(t *testing.T) {
}
