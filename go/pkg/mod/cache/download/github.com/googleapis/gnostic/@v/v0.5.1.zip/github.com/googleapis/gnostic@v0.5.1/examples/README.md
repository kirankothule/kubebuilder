# examples

This directory contains example descriptions of APIs.
