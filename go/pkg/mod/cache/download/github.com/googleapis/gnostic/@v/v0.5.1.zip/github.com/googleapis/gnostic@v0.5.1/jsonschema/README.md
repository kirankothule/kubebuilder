# jsonschema

This directory contains code for reading, writing, and manipulating JSON
schemas.
