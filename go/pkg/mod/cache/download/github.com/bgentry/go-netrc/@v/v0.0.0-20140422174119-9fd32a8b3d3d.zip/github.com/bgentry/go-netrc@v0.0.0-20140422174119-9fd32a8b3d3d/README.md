# go-netrc

A Golang package for reading and writing netrc files. This package can parse netrc
files, make changes to them, and then serialize them back to netrc format, while
preserving any whitespace that was present in the source file.

[![GoDoc](https://godoc.org/github.com/bgentry/go-netrc?status.png)][godoc]

[godoc]: https://godoc.org/github.com/bgentry/go-netrc "go-netrc on Godoc.org"
