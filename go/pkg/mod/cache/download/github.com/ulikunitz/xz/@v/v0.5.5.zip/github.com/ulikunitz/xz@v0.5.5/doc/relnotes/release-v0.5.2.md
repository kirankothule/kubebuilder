# Release Notes v0.5.2

The release fixes an issue decoding files that contain a block header
padding of 4 bytes.

Many thanks to Greg (@myfreeweb on github) for reporting this issue.
