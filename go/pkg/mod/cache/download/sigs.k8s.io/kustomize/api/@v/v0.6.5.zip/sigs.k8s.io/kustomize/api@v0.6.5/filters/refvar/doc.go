// Package refvar contains a kio.Filter implementation of the kustomize
// refvar transformer.
package refvar
